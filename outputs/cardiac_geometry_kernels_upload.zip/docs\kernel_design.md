# Kernel Design

## FasTFit Fitting

The fitting path follows the FasTFit paper's adaptive patch generation. Work is
organized around independent rectangular regions in a fixed 2D parameter
domain:

```text
parallel worker = fit one candidate region with one Bezier least-squares solve
```

Each worker:

1. Selects data points inside the region.
2. Builds a tensor-product Bernstein design matrix.
3. Solves the regularized or unregularized least-squares problem.
4. Computes RMSE and maximum fitting error.

Regions whose error exceeds the requested threshold are split along the longer
parameter-domain side. Pending regions are processed in deterministic batches,
so serial and threaded runs produce equivalent models.

The accepted patch network is the paper's full-multiplicity T-spline baseline.
It can be evaluated directly as piecewise Bezier patches or exported to local
knot vectors where each patch boundary is repeated `degree + 1` times.

## Surface Evaluation

The baseline GPU mapping is:

```text
one CUDA thread or Triton program element = one output sample `(u_idx, v_idx)`
```

Each worker:

1. Loads the `u` and `v` sample values.
2. Loops over all control points.
3. Evaluates the local basis in both parameter directions.
4. Accumulates weighted numerator coordinates and denominator.
5. Writes one `x, y, z` output.

This fuses basis evaluation and rational accumulation. The kernel avoids writing
the dense basis tensor with shape `U x V x C`.

## Memory Layout

The current source uses an array-of-structures control-point layout:

```text
control_points[C, 3]
knots_u[C, degree + 2]
knots_v[C, degree + 2]
weights[C]
```

This matches the NumPy reference and original data. A future optimization should
compare this against structure-of-arrays control points (`Px`, `Py`, `Pz`) and
constant-memory/read-only-cache placement for small control meshes.

## Degree Specialization

The CUDA kernel supports degrees up to 8 through an iterative local routine. The
Triton prototype specializes degree 2, which matches the bundled tube and
bifurcation samples and gives the compiler a simpler loop body.

## Chamfer Distance

The CUDA Chamfer kernel is a correctness baseline that assigns one thread to one
source point and loops over target points. The Triton version tiles target
points within each program. The next optimization is a shared-memory CUDA tile
that reduces global loads for larger point clouds.

## Known Limitations

- CUDA and Triton paths currently focus on float32 forward evaluation.
- Custom backward kernels are not implemented yet.
- Triton T-spline evaluation is degree-2 only.
- GPU code must be built and profiled on a CUDA-enabled workstation.
