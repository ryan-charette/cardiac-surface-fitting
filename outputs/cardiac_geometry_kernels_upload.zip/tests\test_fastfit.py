import unittest

import numpy as np

from cardiac_geometry.fastfit import FastFitOptions, bernstein_basis, fit_fastfit_surface
from cardiac_geometry.reference.tspline_numpy import evaluate_tspline_numpy


def _smooth_test_surface(num_u=25, num_v=21):
    u = np.linspace(0.0, 1.0, num_u)
    v = np.linspace(0.0, 1.0, num_v)
    uu, vv = np.meshgrid(u, v, indexing="ij")
    xyz = np.empty(uu.shape + (3,), dtype=np.float64)
    xyz[..., 0] = uu
    xyz[..., 1] = vv
    xyz[..., 2] = 0.25 * uu * uu - 0.5 * uu * vv + 0.1 * vv
    return xyz


class FastFitTests(unittest.TestCase):
    def test_bernstein_partition_of_unity(self):
        samples = np.linspace(0.0, 1.0, 11)
        basis = bernstein_basis(samples, degree=3)
        np.testing.assert_allclose(basis.sum(axis=-1), 1.0, atol=1e-14)

    def test_single_patch_recovers_polynomial_surface(self):
        xyz = _smooth_test_surface()
        model = fit_fastfit_surface(
            xyz,
            options=FastFitOptions(
                degree=3,
                max_error=1e-10,
                initial_splits=(1, 1),
                workers=1,
            ),
        )
        self.assertEqual(len(model.patches), 1)
        u = np.linspace(0.0, 1.0, xyz.shape[0])
        v = np.linspace(0.0, 1.0, xyz.shape[1])
        fitted = model.evaluate(u, v)
        np.testing.assert_allclose(fitted, xyz, atol=1e-12, rtol=0.0)

    def test_adaptive_split_creates_multiple_patches_for_discontinuity(self):
        xyz = _smooth_test_surface(33, 29)
        xyz[17:, :, 2] += 0.75
        model = fit_fastfit_surface(
            xyz,
            options=FastFitOptions(
                degree=3,
                max_error=0.05,
                initial_splits=(1, 1),
                max_depth=4,
                workers=2,
            ),
        )
        self.assertGreater(len(model.patches), 1)
        self.assertLess(model.diagnostics["max_patch_error"], 0.75)

    def test_parallel_and_serial_are_deterministic(self):
        xyz = _smooth_test_surface(31, 27)
        options = FastFitOptions(
            degree=3,
            max_error=1e-8,
            initial_splits=(2, 2),
            max_depth=2,
            workers=1,
        )
        serial = fit_fastfit_surface(xyz, options=options)
        parallel = fit_fastfit_surface(
            xyz,
            options=FastFitOptions(
                degree=3,
                max_error=1e-8,
                initial_splits=(2, 2),
                max_depth=2,
                workers=4,
            ),
        )
        self.assertEqual(len(serial.patches), len(parallel.patches))
        u = np.linspace(0.0, 1.0, 9)
        v = np.linspace(0.0, 1.0, 7)
        np.testing.assert_allclose(serial.evaluate(u, v), parallel.evaluate(u, v), atol=1e-12)

    def test_evaluate_points_uses_paired_parameters(self):
        xyz = _smooth_test_surface()
        model = fit_fastfit_surface(
            xyz,
            options=FastFitOptions(degree=3, max_error=1e-10, initial_splits=(1, 1)),
        )
        params = np.array([[0.1, 0.2], [0.4, 0.6], [0.8, 0.3]])
        values = model.evaluate_points(params)
        expected = np.column_stack(
            [
                params[:, 0],
                params[:, 1],
                0.25 * params[:, 0] ** 2
                - 0.5 * params[:, 0] * params[:, 1]
                + 0.1 * params[:, 1],
            ]
        )
        np.testing.assert_allclose(values, expected, atol=1e-12, rtol=0.0)

    def test_local_knot_export_shapes(self):
        model = fit_fastfit_surface(
            _smooth_test_surface(),
            options=FastFitOptions(degree=3, max_error=1e-10, initial_splits=(1, 1)),
        )
        knots_u, knots_v, points, anchors = model.to_local_knot_surface()
        self.assertEqual(knots_u.shape, (16, 5))
        self.assertEqual(knots_v.shape, (16, 5))
        self.assertEqual(points.shape, (16, 3))
        self.assertEqual(anchors.shape, (16, 2))

    def test_full_multiplicity_export_matches_local_knot_evaluator_interior(self):
        model = fit_fastfit_surface(
            _smooth_test_surface(),
            options=FastFitOptions(degree=3, max_error=1e-10, initial_splits=(1, 1)),
        )
        knots_u, knots_v, points, _ = model.to_local_knot_surface()
        u = np.array([0.2, 0.4, 0.8])
        v = np.array([0.15, 0.55, 0.85])
        piecewise = model.evaluate(u, v)
        local_knot = evaluate_tspline_numpy(
            u,
            v,
            knots_u,
            knots_v,
            points,
            np.ones(points.shape[0]),
            degree=model.degree,
        )
        np.testing.assert_allclose(piecewise, local_knot, atol=1e-12, rtol=0.0)


if __name__ == "__main__":
    unittest.main()
