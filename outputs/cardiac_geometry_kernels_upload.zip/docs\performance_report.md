# Performance Report

This report records CPU-side benchmark results from the local Codex workspace.
Do not claim CUDA/Triton speedups until the GPU paths are run on target
hardware.

## Hardware

- GPU: not benchmarked in this environment
- CPU: local Windows host, exact CPU query blocked by sandbox permissions
- CUDA: unavailable from this environment (`nvidia-smi`, `nvcc`, and
  `C:\Windows\System32\nvcuda.dll` not found)
- Driver: TBD
- PyTorch: 2.11.0+cpu installed in `.venv`
- Triton: 3.6.0 import available via `triton-windows`, runtime unavailable
  because no CUDA device/driver is visible
- Python: 3.12.13 in `.venv`
- NumPy: 2.4.4 in `.venv`

## Workloads

- Tube sample: 42 local control entries.
- Bifurcation sample: 84 local control entries.
- Surface grids: `80 x 40`, `400 x 200`, `1024 x 1024`.
- Chamfer point clouds: synthetic and sample-surface point sets.

## Commands

```bash
python -m unittest discover -s tests
python benchmarks/benchmark_tspline.py --case bifurcation --grid 80 40
python benchmarks/benchmark_fastfit.py --case tube --grid 64 48 --workers 1 2 4
python benchmarks/benchmark_chamfer.py --source-points 2048 --target-points 2048
python benchmarks/benchmark_la_memory.py --thresholds 2 3 5 8 12 --workers 4
python benchmarks/benchmark_torch_cpu.py --case bifurcation --grid 80 40 --chamfer-points 2048 --repeats 3 --threads 4
```

## FasTFit Runtime Table

| Case | Grid | Workers | Patches | Control points | Fit ms |
|---|---:|---:|---:|---:|---:|
| tube | 64 x 48 | 1 | 16 | 256 | 11.939 |
| tube | 64 x 48 | 2 | 16 | 256 | 11.780 |
| tube | 64 x 48 | 4 | 16 | 256 | 12.101 |

For this small tube case, threading overhead dominates; the work is too small
to show a CPU parallel speedup.

## LA Point-Cloud Memory Results

The LA point clouds were read from `heart-modeling-main.zip` and parameterized
with the PCA projection described in the FasTFit paper for unorganized point
clouds. Results below use degree-3 patches, `4 x 4` initial regions, max depth
10, and 4 workers.

Two fitted-model storage estimates are reported:

- Compact patch model: per patch, store 16 control points and 4 domain bounds.
- Expanded local knots: explicitly store duplicated local knot vectors,
  weights, and control points for every full-multiplicity control entry.

| Cloud | Split threshold | Points | Patches | Ctrl pts | Fit ms | RMSE | Compact f64 KiB | Raw f64 KiB | Compact saved vs raw | Expanded local-knot f64 KiB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ED | 2.0 | 9,123 | 311 | 4,976 | 348.104 | 9.446 | 126.344 | 213.820 | 40.9% | 544.250 |
| ED | 5.0 | 9,123 | 303 | 4,848 | 318.841 | 9.447 | 123.094 | 213.820 | 42.4% | 530.250 |
| ED | 12.0 | 9,123 | 272 | 4,352 | 284.479 | 9.505 | 110.500 | 213.820 | 48.3% | 476.000 |
| ES | 2.0 | 8,677 | 256 | 4,096 | 265.745 | 9.837 | 104.000 | 203.367 | 48.9% | 448.000 |
| ES | 5.0 | 8,677 | 252 | 4,032 | 269.312 | 9.837 | 102.375 | 203.367 | 49.7% | 441.000 |
| ES | 12.0 | 8,677 | 226 | 3,616 | 232.323 | 9.897 | 91.812 | 203.367 | 54.9% | 395.500 |

The compact fitted representation saves roughly 41-55% against raw float64
point arrays, and roughly 66-70% against the original text files at the most
compact threshold shown. The expanded duplicated-knot table is larger than raw
float64 storage, so it should be treated as an interchange/debug format rather
than the memory-efficient representation.

The RMSE does not improve much below threshold 12 because PCA parameterization
is a weak fit for these curved atrial point clouds. That is an algorithmic
limitation worth stating honestly; better anatomical parameterization or the
paper's smooth T-mesh connection stage is the next lever.

## Accuracy Table

| Method | Reference | Max abs error | Mean abs error |
|---|---:|---:|---:|
| NumPy fused mapping | NumPy vectorized | TBD | TBD |
| CUDA fused | NumPy vectorized | TBD | TBD |
| Triton degree-2 | NumPy vectorized | TBD | TBD |

## Runtime Table

| Method | Grid | Control points | Mean ms | Samples/s |
|---|---:|---:|---:|---:|
| NumPy vectorized | 80 x 40 | 84 | 77.604 | 41,234.7 |
| PyTorch framework CPU | 80 x 40 | 84 | 69.793 | 45,850.1 |
| NumPy fused mapping | 80 x 40 | 84 | 5,483.905 | 583.5 |
| CUDA fused | TBD | TBD | TBD | TBD |
| Triton degree-2 | TBD | TBD | TBD | TBD |

The pure-Python fused mapping is intentionally slow; it exists as a correctness
mirror of the CUDA/Triton thread mapping, not as the CPU performance baseline.

## Chamfer CPU Baseline

| Method | Points x points | Mean ms | Points/s | Error vs NumPy |
|---|---:|---:|---:|---:|
| NumPy chunked | 2,048 x 2,048 | 248.890 | 8,228.5 | 0 |
| PyTorch `cdist` CPU | 2,048 x 2,048 | 20.028 | 102,255.0 | 2.64e-10 |

On CPU, PyTorch `cdist` was about 12.4x faster than the chunked NumPy Chamfer
reference for the 2,048-point synthetic benchmark.

## Triton/CUDA Status

PyTorch and Triton are installed in `.venv`, but GPU execution is blocked on
this host:

```text
torch=2.11.0+cpu
torch_cuda_version=None
torch_cuda_available=False
triton=3.6.0
triton_runtime_status=unavailable_no_cuda_device
```

This means CUDA extension and Triton kernel timing still need to be run on a
machine with an NVIDIA driver, CUDA-capable PyTorch wheel, and a visible GPU.

## Profiler Notes

Use Nsight Compute for CUDA kernels and record:

- achieved occupancy
- memory throughput
- register count
- branch efficiency
- global load efficiency
- launch overhead for small grids
