# Outputs

Generated surfaces, benchmark CSVs, and profiler exports are written here by
examples and benchmark scripts. The directory is kept in git, but generated
files are ignored.

