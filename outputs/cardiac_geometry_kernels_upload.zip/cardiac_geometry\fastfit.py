"""Parallel FasTFit-style T-spline fitting.

This module implements the split-fit part of Feng and Taguchi's FasTFit
algorithm for fixed 2D-parameterized point clouds. The returned model is a
piecewise Bezier patch network. As noted in the paper, the adaptive Bezier
patch set is already a valid T-spline when each patch boundary has full knot
multiplicity. That representation is intentionally used here as the robust
parallel baseline before adding lower-multiplicity continuity inference.
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from math import comb
from typing import Iterable

import numpy as np


@dataclass(frozen=True)
class FastFitOptions:
    """Configuration for the parallel FasTFit implementation."""

    degree: int = 3
    max_error: float = 0.02
    initial_splits: tuple[int, int] = (4, 4)
    max_depth: int = 10
    smoothing: float = 0.0
    min_points_per_patch: int | None = None
    workers: int | None = None
    keep_unsplittable: bool = True

    def control_count(self) -> int:
        return (self.degree + 1) * (self.degree + 1)

    def effective_min_points(self) -> int:
        if self.min_points_per_patch is not None:
            return self.min_points_per_patch
        return self.control_count()


@dataclass(frozen=True)
class _Region:
    u_min: float
    u_max: float
    v_min: float
    v_max: float
    depth: int = 0

    def contains(self, params: np.ndarray, *, include_upper: bool = True) -> np.ndarray:
        if include_upper:
            return (
                (params[:, 0] >= self.u_min)
                & (params[:, 0] <= self.u_max)
                & (params[:, 1] >= self.v_min)
                & (params[:, 1] <= self.v_max)
            )
        return (
            (params[:, 0] >= self.u_min)
            & (params[:, 0] < self.u_max)
            & (params[:, 1] >= self.v_min)
            & (params[:, 1] < self.v_max)
        )

    def split(self) -> tuple["_Region", "_Region"]:
        u_span = self.u_max - self.u_min
        v_span = self.v_max - self.v_min
        if u_span >= v_span:
            mid = 0.5 * (self.u_min + self.u_max)
            return (
                _Region(self.u_min, mid, self.v_min, self.v_max, self.depth + 1),
                _Region(mid, self.u_max, self.v_min, self.v_max, self.depth + 1),
            )
        mid = 0.5 * (self.v_min + self.v_max)
        return (
            _Region(self.u_min, self.u_max, self.v_min, mid, self.depth + 1),
            _Region(self.u_min, self.u_max, mid, self.v_max, self.depth + 1),
        )


@dataclass(frozen=True)
class BezierPatch:
    """One fitted Bezier patch over a rectangular parameter domain."""

    u_min: float
    u_max: float
    v_min: float
    v_max: float
    degree: int
    control_points: np.ndarray
    rmse: float
    max_error: float
    num_points: int
    rank: int
    depth: int

    def evaluate(self, u: np.ndarray, v: np.ndarray) -> np.ndarray:
        """Evaluate this patch for same-shaped parameter arrays."""

        u_local = _normalize_parameter(u, self.u_min, self.u_max)
        v_local = _normalize_parameter(v, self.v_min, self.v_max)
        bu = bernstein_basis(u_local, self.degree)
        bv = bernstein_basis(v_local, self.degree)
        controls = self.control_points.reshape(
            self.degree + 1, self.degree + 1, 3
        )
        return np.einsum("...i,...j,ijc->...c", bu, bv, controls)

    def local_knot_vectors(self) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Return local knot vectors/control points for the full-multiplicity form."""

        ku = []
        kv = []
        anchors = []
        points = []
        for i in range(self.degree + 1):
            u_knots = np.array(
                [self.u_min] * (self.degree + 1 - i)
                + [self.u_max] * (i + 1),
                dtype=np.float64,
            )
            for j in range(self.degree + 1):
                v_knots = np.array(
                    [self.v_min] * (self.degree + 1 - j)
                    + [self.v_max] * (j + 1),
                    dtype=np.float64,
                )
                ku.append(u_knots)
                kv.append(v_knots)
                anchors.append(
                    [
                        self.u_min + (self.u_max - self.u_min) * i / self.degree,
                        self.v_min + (self.v_max - self.v_min) * j / self.degree,
                    ]
                )
                points.append(self.control_points[i * (self.degree + 1) + j])
        return (
            np.asarray(ku),
            np.asarray(kv),
            np.asarray(points),
            np.asarray(anchors),
        )


@dataclass(frozen=True)
class FastFitSurface:
    """A fitted piecewise Bezier/T-spline surface."""

    patches: tuple[BezierPatch, ...]
    degree: int
    domain: tuple[float, float, float, float]
    options: FastFitOptions
    diagnostics: dict[str, float | int] = field(default_factory=dict)

    @property
    def num_control_points(self) -> int:
        return len(self.patches) * (self.degree + 1) * (self.degree + 1)

    def evaluate(
        self,
        u: np.ndarray | Iterable[float],
        v: np.ndarray | Iterable[float],
        *,
        workers: int | None = None,
    ) -> np.ndarray:
        """Evaluate the fitted surface on vector or mesh parameters."""

        u_arr = np.asarray(u, dtype=np.float64)
        v_arr = np.asarray(v, dtype=np.float64)
        vector_input = u_arr.ndim == 1 and v_arr.ndim == 1
        if vector_input:
            uu, vv = np.meshgrid(u_arr, v_arr, indexing="ij")
        elif u_arr.ndim == 2 and v_arr.ndim == 2 and u_arr.shape == v_arr.shape:
            uu, vv = u_arr, v_arr
        else:
            raise ValueError("u and v must either both be 1D or matching 2D arrays")

        params = np.column_stack([uu.reshape(-1), vv.reshape(-1)])
        out = np.full((params.shape[0], 3), np.nan, dtype=np.float64)
        patch_indices = self._locate_patches(params)

        def eval_patch(patch_index: int) -> tuple[np.ndarray, np.ndarray]:
            mask = patch_indices == patch_index
            patch = self.patches[patch_index]
            values = patch.evaluate(params[mask, 0], params[mask, 1])
            return np.flatnonzero(mask), values

        active = [idx for idx in range(len(self.patches)) if np.any(patch_indices == idx)]
        if workers is None:
            workers = self.options.workers
        if workers is not None and workers > 1 and len(active) > 1:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                for indices, values in pool.map(eval_patch, active):
                    out[indices] = values
        else:
            for patch_index in active:
                indices, values = eval_patch(patch_index)
                out[indices] = values

        if np.any(~np.isfinite(out)):
            missing = int(np.count_nonzero(~np.isfinite(out[:, 0])))
            raise ValueError(f"{missing} evaluation sample(s) fell outside all patches")
        return out.reshape(uu.shape + (3,))

    def evaluate_points(
        self,
        parameters: np.ndarray | Iterable[Iterable[float]],
        *,
        workers: int | None = None,
    ) -> np.ndarray:
        """Evaluate this model at paired ``(u, v)`` parameter samples."""

        params = np.asarray(parameters, dtype=np.float64)
        if params.ndim != 2 or params.shape[1] != 2:
            raise ValueError("parameters must have shape (num_samples, 2)")
        if not np.all(np.isfinite(params)):
            raise ValueError("parameters must contain only finite values")

        out = np.full((params.shape[0], 3), np.nan, dtype=np.float64)
        patch_indices = self._locate_patches(params)

        def eval_patch(patch_index: int) -> tuple[np.ndarray, np.ndarray]:
            mask = patch_indices == patch_index
            patch = self.patches[patch_index]
            values = patch.evaluate(params[mask, 0], params[mask, 1])
            return np.flatnonzero(mask), values

        active = [idx for idx in range(len(self.patches)) if np.any(patch_indices == idx)]
        if workers is None:
            workers = self.options.workers
        if workers is not None and workers > 1 and len(active) > 1:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                for indices, values in pool.map(eval_patch, active):
                    out[indices] = values
        else:
            for patch_index in active:
                indices, values = eval_patch(patch_index)
                out[indices] = values

        if np.any(~np.isfinite(out)):
            missing = int(np.count_nonzero(~np.isfinite(out[:, 0])))
            raise ValueError(f"{missing} evaluation sample(s) fell outside all patches")
        return out

    def to_local_knot_surface(self) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Return a full-multiplicity local-knot representation of all patches."""

        knots_u = []
        knots_v = []
        points = []
        anchors = []
        for patch in self.patches:
            ku, kv, cp, an = patch.local_knot_vectors()
            knots_u.append(ku)
            knots_v.append(kv)
            points.append(cp)
            anchors.append(an)
        return (
            np.vstack(knots_u),
            np.vstack(knots_v),
            np.vstack(points),
            np.vstack(anchors),
        )

    def _locate_patches(self, params: np.ndarray) -> np.ndarray:
        indices = np.full(params.shape[0], -1, dtype=np.int64)
        # Choose the first matching patch in deterministic top-left order. Shared
        # boundaries are therefore assigned to exactly one full-multiplicity patch.
        for patch_index, patch in enumerate(self.patches):
            region = _Region(patch.u_min, patch.u_max, patch.v_min, patch.v_max)
            mask = region.contains(params) & (indices < 0)
            indices[mask] = patch_index
        return indices


def bernstein_basis(x: np.ndarray | Iterable[float], degree: int) -> np.ndarray:
    """Evaluate all Bernstein basis polynomials of ``degree`` at ``x``."""

    if degree < 0:
        raise ValueError("degree must be non-negative")
    arr = np.asarray(x, dtype=np.float64)
    if not np.all(np.isfinite(arr)):
        raise ValueError("parameter samples must be finite")
    arr = np.clip(arr, 0.0, 1.0)
    out = np.empty(arr.shape + (degree + 1,), dtype=np.float64)
    for i in range(degree + 1):
        out[..., i] = comb(degree, i) * (arr**i) * ((1.0 - arr) ** (degree - i))
    return out


def fit_fastfit_surface(
    points: np.ndarray | Iterable[Iterable[float]],
    *,
    parameters: np.ndarray | Iterable[Iterable[float]] | None = None,
    mask: np.ndarray | Iterable[bool] | None = None,
    options: FastFitOptions | None = None,
) -> FastFitSurface:
    """Fit a piecewise T-spline/Bezier surface using FasTFit's split stage.

    ``points`` can be either an organized array shaped ``(M, N, 3)`` or a flat
    array shaped ``(P, 3)`` with matching ``parameters`` shaped ``(P, 2)``.
    Organized inputs receive a uniform fixed parameterization over ``[0, 1]^2``.
    """

    opts = options or FastFitOptions()
    params, xyz = _prepare_parameterized_points(points, parameters, mask)
    domain = (
        float(np.min(params[:, 0])),
        float(np.max(params[:, 0])),
        float(np.min(params[:, 1])),
        float(np.max(params[:, 1])),
    )
    regions = _initial_regions(domain, opts.initial_splits)
    patches, fitted_regions, skipped_regions = _adaptive_fit_regions(params, xyz, regions, opts)
    patches = tuple(
        sorted(patches, key=lambda p: (p.u_min, p.v_min, p.u_max, p.v_max, p.depth))
    )
    if not patches:
        raise RuntimeError("FasTFit did not produce any valid patches")

    diagnostics = {
        "patches": len(patches),
        "control_points": len(patches) * opts.control_count(),
        "fitted_regions": fitted_regions,
        "skipped_regions": skipped_regions,
        "mean_patch_rmse": float(np.mean([p.rmse for p in patches])),
        "max_patch_error": float(np.max([p.max_error for p in patches])),
    }
    return FastFitSurface(patches, opts.degree, domain, opts, diagnostics)


def fit_bezier_patch(
    parameters: np.ndarray,
    points: np.ndarray,
    region: tuple[float, float, float, float],
    *,
    degree: int = 3,
    smoothing: float = 0.0,
    depth: int = 0,
) -> BezierPatch | None:
    """Fit one Bezier patch by least squares as in FasTFit's Eq. (2)."""

    reg = _Region(*region)
    selected = reg.contains(parameters)
    params = parameters[selected]
    xyz = points[selected]
    control_count = (degree + 1) * (degree + 1)
    if xyz.shape[0] < control_count and smoothing <= 0.0:
        return None

    design = _bezier_design_matrix(params, reg, degree)
    rhs = xyz
    if smoothing > 0.0:
        penalty = np.sqrt(smoothing) * np.eye(control_count, dtype=np.float64)
        design_solve = np.vstack([design, penalty])
        rhs_solve = np.vstack([rhs, np.zeros((control_count, 3), dtype=np.float64)])
    else:
        design_solve = design
        rhs_solve = rhs

    try:
        control_points, _, rank, _ = np.linalg.lstsq(design_solve, rhs_solve, rcond=None)
    except np.linalg.LinAlgError:
        return None
    if rank < min(control_count, design_solve.shape[0]) and smoothing <= 0.0:
        return None

    residual = design @ control_points - xyz
    distances = np.linalg.norm(residual, axis=1)
    rmse = float(np.sqrt(np.mean(distances * distances))) if distances.size else 0.0
    max_error = float(np.max(distances)) if distances.size else 0.0
    return BezierPatch(
        reg.u_min,
        reg.u_max,
        reg.v_min,
        reg.v_max,
        degree,
        control_points,
        rmse,
        max_error,
        int(xyz.shape[0]),
        int(rank),
        depth,
    )


def _prepare_parameterized_points(
    points: np.ndarray | Iterable[Iterable[float]],
    parameters: np.ndarray | Iterable[Iterable[float]] | None,
    mask: np.ndarray | Iterable[bool] | None,
) -> tuple[np.ndarray, np.ndarray]:
    arr = np.asarray(points, dtype=np.float64)
    if arr.ndim == 3 and arr.shape[2] == 3:
        m, n, _ = arr.shape
        u = np.linspace(0.0, 1.0, m)
        v = np.linspace(0.0, 1.0, n)
        uu, vv = np.meshgrid(u, v, indexing="ij")
        params = np.column_stack([uu.reshape(-1), vv.reshape(-1)])
        xyz = arr.reshape(-1, 3)
        valid = np.all(np.isfinite(xyz), axis=1)
        if mask is not None:
            valid &= np.asarray(mask, dtype=bool).reshape(-1)
        return params[valid], xyz[valid]

    if arr.ndim != 2 or arr.shape[1] != 3:
        raise ValueError("points must have shape (M, N, 3) or (P, 3)")
    if parameters is None:
        raise ValueError("flat points require parameters with shape (P, 2)")
    params = np.asarray(parameters, dtype=np.float64)
    if params.ndim != 2 or params.shape[1] != 2 or params.shape[0] != arr.shape[0]:
        raise ValueError("parameters must have shape (P, 2)")
    valid = np.all(np.isfinite(arr), axis=1) & np.all(np.isfinite(params), axis=1)
    if mask is not None:
        valid &= np.asarray(mask, dtype=bool).reshape(-1)
    return params[valid], arr[valid]


def _normalize_parameter(values: np.ndarray, min_value: float, max_value: float) -> np.ndarray:
    span = max_value - min_value
    if span <= 0.0:
        raise ValueError("patch parameter domain has zero width")
    return (np.asarray(values, dtype=np.float64) - min_value) / span


def _bezier_design_matrix(params: np.ndarray, region: _Region, degree: int) -> np.ndarray:
    control_count = (degree + 1) * (degree + 1)
    if params.shape[0] == 0:
        return np.empty((0, control_count), dtype=np.float64)
    u_local = _normalize_parameter(params[:, 0], region.u_min, region.u_max)
    v_local = _normalize_parameter(params[:, 1], region.v_min, region.v_max)
    bu = bernstein_basis(u_local, degree)
    bv = bernstein_basis(v_local, degree)
    return (bu[:, :, None] * bv[:, None, :]).reshape(params.shape[0], control_count)


def _initial_regions(
    domain: tuple[float, float, float, float],
    splits: tuple[int, int],
) -> list[_Region]:
    if splits[0] <= 0 or splits[1] <= 0:
        raise ValueError("initial_splits must be positive")
    u_min, u_max, v_min, v_max = domain
    u_edges = np.linspace(u_min, u_max, splits[0] + 1)
    v_edges = np.linspace(v_min, v_max, splits[1] + 1)
    regions = []
    for i in range(splits[0]):
        for j in range(splits[1]):
            regions.append(_Region(u_edges[i], u_edges[i + 1], v_edges[j], v_edges[j + 1]))
    return regions


def _adaptive_fit_regions(
    params: np.ndarray,
    points: np.ndarray,
    initial_regions: list[_Region],
    opts: FastFitOptions,
) -> tuple[list[BezierPatch], int, int]:
    pending = list(initial_regions)
    patches: list[BezierPatch] = []
    fitted_regions = 0
    skipped_regions = 0

    while pending:
        pending = sorted(pending, key=lambda r: (r.depth, r.u_min, r.v_min, r.u_max, r.v_max))

        def fit_region(region: _Region) -> tuple[_Region, BezierPatch | None, int]:
            selected_count = int(np.count_nonzero(region.contains(params)))
            if selected_count < opts.effective_min_points() and opts.smoothing <= 0.0:
                return region, None, selected_count
            patch = fit_bezier_patch(
                params,
                points,
                (region.u_min, region.u_max, region.v_min, region.v_max),
                degree=opts.degree,
                smoothing=opts.smoothing,
                depth=region.depth,
            )
            return region, patch, selected_count

        if opts.workers is not None and opts.workers > 1 and len(pending) > 1:
            with ThreadPoolExecutor(max_workers=opts.workers) as pool:
                results = list(pool.map(fit_region, pending))
        else:
            results = [fit_region(region) for region in pending]

        pending = []
        for region, patch, selected_count in results:
            if patch is None:
                skipped_regions += 1
                continue
            fitted_regions += 1
            should_split = patch.max_error > opts.max_error and region.depth < opts.max_depth
            if should_split and _can_split(region, params, opts):
                pending.extend(region.split())
            elif opts.keep_unsplittable or not should_split:
                patches.append(patch)
            else:
                skipped_regions += 1
    return patches, fitted_regions, skipped_regions


def _can_split(region: _Region, params: np.ndarray, opts: FastFitOptions) -> bool:
    if region.u_max <= region.u_min or region.v_max <= region.v_min:
        return False
    minimum = opts.effective_min_points()
    return all(np.count_nonzero(child.contains(params)) >= minimum for child in region.split())
