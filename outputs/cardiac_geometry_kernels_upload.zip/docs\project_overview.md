# Project Overview

This project refactors the original heart-modeling T-spline scripts into a
performance-engineering repository. The original local-knot evaluator is kept as
a validation and kernel target, while point-cloud fitting now follows the
FasTFit split-connect-fit paper supplied with this task.

The important shift is from exploratory scientific scripts to a tested package:
data loading, basis evaluation, surface evaluation, GPU kernels, benchmarks, and
documentation are separated so each layer can be validated independently.

## Correctness Audit Findings

The original `tsplines.py` implementation was useful as a prototype, but it had
several issues that would become sharp edges in GPU code:

- Recursive basis evaluation only handled infinite division results, not NaNs
  from repeated local knots.
- Half-open basis intervals make right-endpoint samples evaluate to zero
  support when a grid includes the upper boundary.
- Basis normalization could divide by zero outside support.
- The T-mesh initializer assumed each parameter column was densely filled from
  row zero. The provided tube and bifurcation samples satisfy that assumption,
  but the cleaned loader uses actual `(row, col)` indices.
- Numerical code and plotting were mixed together, making tests and kernel
  comparisons harder.

The cleaned NumPy evaluator fixes those issues and raises explicit errors for
invalid inputs or zero rational denominators. It is no longer presented as the
surface-fitting algorithm.

## FasTFit Replacement

The fitting implementation in `cardiac_geometry.fastfit` follows the paper's
Algorithm 2 as the parallel baseline:

- Uniformly initialize rectangular regions over a fixed 2D parameter domain.
- Fit each region with a degree-`d` Bezier patch by least squares.
- Split regions whose maximum fitting error exceeds the requested threshold.
- Fit pending regions in deterministic batches using a thread pool.
- Return the accepted Bezier patch network.

The paper notes that this patch set is already a valid T-spline when every
patch boundary has full knot multiplicity, i.e. multiplicity `degree + 1`. This
is the representation implemented here. The module can export those patches as
local knot vectors through `FastFitSurface.to_local_knot_surface()`.

The lower-multiplicity smooth connection stage from Algorithm 3 is deliberately
not faked. It requires full face-edge-vertex T-mesh operations, continuity
classification, and anchor generation around T-junctions. The current
implementation is therefore a correct full-multiplicity FasTFit baseline rather
than an incomplete smooth T-spline connector.

## Implemented Tracks

- Track A: cleaned NumPy reference, sample-data loader, FasTFit fitting
  implementation, tests, examples, and benchmark scripts.
- Track B: fused CUDA forward-kernel source and PyTorch extension binding.
- Track C: PyTorch framework-native differentiable fallback and Triton degree-2
  prototype.
- Track D: NumPy, PyTorch, CUDA, and Triton Chamfer-distance scaffolding.

## Next GPU Validation Step

On a CUDA workstation, install PyTorch with CUDA, build the extension through
`cardiac_geometry.torch_ops.tspline_op.load_cuda_extension`, then compare CUDA
outputs against `evaluate_tspline_numpy` for the bundled samples.
