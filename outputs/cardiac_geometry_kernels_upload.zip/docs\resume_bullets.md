# Resume Bullets

Replace any performance placeholders with measured results after running on a
CUDA workstation.

- Built a CUDA/Triton cardiac geometry engine for rational T-spline surface
  evaluation and point-cloud fitting, starting from a NumPy research prototype.
- Implemented a fused CUDA forward kernel that evaluates local B-spline bases
  and rational surface coordinates in one pass, avoiding dense `U x V x C`
  basis-tensor materialization.
- Refactored exploratory T-spline scripts into a tested Python package with
  deterministic NumPy reference math, sample-data loaders, benchmarks, and
  GPU-extension scaffolding.
- Added Chamfer-distance reference and GPU paths for surface-to-point-cloud
  fitting experiments.

