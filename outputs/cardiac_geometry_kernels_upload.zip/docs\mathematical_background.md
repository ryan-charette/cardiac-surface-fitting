# Mathematical Background

For each parameter pair `(u, v)`, the rational T-spline surface is evaluated as:

```text
S(u, v) = sum_i B_i(u, v) * w_i * P_i / sum_i B_i(u, v) * w_i
```

where:

- `P_i` is control point `i`.
- `w_i` is the rational weight for control point `i`.
- `B_i(u, v)` is the tensor product of two local B-spline basis functions.

The local basis uses a Cox-de Boor recurrence over a compact knot vector of
width `degree + 2`. The cleaned implementation evaluates this recurrence
iteratively:

```text
N_i,0(x) = 1 if knot_i <= x < knot_{i+1}, otherwise 0
N_i,p(x) = a * N_i,p-1(x) + b * N_i+1,p-1(x)
```

Zero-length knot intervals are treated as contributing zero to the recurrence,
which avoids NaNs for repeated knots.

## FasTFit Bezier Patch Fitting

For a candidate rectangular parameter region, FasTFit fits a degree-`d` Bezier
surface by least squares:

```text
P* = argmin_P || B P - Q ||_F^2 + lambda || S P ||_F^2
```

`Q` stores the 3D points in the region, and each row of `B` stores tensor-product
Bernstein basis values at the corresponding 2D parameter. The implementation
uses the identity matrix as the optional stabilizing penalty when `lambda > 0`.
